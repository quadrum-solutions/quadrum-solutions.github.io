import { v4 as uuid } from 'uuid';
import dayjs from 'dayjs';

const reportsCalendar = [
  {
    id: uuid(),
    title: `MONA_U_X`,
    start: dayjs('2023-02-28').add(17, 'day').format('YYYY-MM-DD'),
    end: dayjs('2023-02-28').add(17, 'day').format('YYYY-MM-DD'),
    extendedProps: {
      reportingDate: '2023-02-28',
      deadline: dayjs('2023-02-28').add(17, 'day').format('YYYY-MM-DD'),
      description:
        'Balance sheet positions and fiduciary business based on the bank accounting rules of the Federal Council and the Swiss Financial Market Supervisory Authority (FINMA)',
      perimeter: 'MONA_U: Parent company</br>MONA_B: Bank office<br/>MONA_US: Parent company',
      requiredBy: 'SNB',
      requirementLink: 'https://emi.snb.ch/fr/emi/MONAX',
      internalRoute: '/statistics/MONA_U'
    },
    display: 'background',
    color: 'primary',
    classNames: `border border-2 border-primary bg-primary`
  },
  {
    id: uuid(),
    title: `ZIR_U`,
    start: dayjs('2023-02-28').add(45, 'day').format('YYYY-MM-DD'),
    end: dayjs('2023-02-28').add(45, 'day').format('YYYY-MM-DD'),
    extendedProps: {
      reportingDate: '2023-02-28',
      deadline: dayjs('2023-02-28').add(45, 'day').format('YYYY-MM-DD'),
      description:
        'Information on interest rate risks in the banking book based on the recording of all material cash flows according to repricing maturity as well as material interest income',
      perimeter: 'ZIR_U: Parent company',
      requiredBy: 'SNB',
      requirementLink: 'https://emi.snb.ch/en/emi/ZIRX',
      internalRoute: '/statistics/ZIR_U'
    },
    display: 'background',
    color: 'warning',
    classNames: `border border-2 border-warning bg-warning`
  },
  {
    id: uuid(),
    title: `LER_U`,
    start: dayjs('2023-02-28').add(42, 'day').format('YYYY-MM-DD'),
    end: dayjs('2023-02-28').add(42, 'day').format('YYYY-MM-DD'),
    extendedProps: {
      reportingDate: '2023-02-28',
      deadline: dayjs('2023-02-28').add(42, 'day').format('YYYY-MM-DD'),
      description:
        'Data in accordance with the large exposure rules and FINMA Circular 19/1 "Risk diversification – banks"',
      perimeter: 'ZIR_U: Parent company',
      requiredBy: 'SNB',
      requirementLink: 'https://emi.snb.ch/en/emi/LERX',
      internalRoute: '/statistics/LER_U'
    },
    display: 'background',
    color: 'warning',
    classNames: `border border-2 border-warning bg-warning`
  },
  {
    id: uuid(),
    title: `LMT_GO`,
    start: dayjs('2023-02-28').add(60, 'day').format('YYYY-MM-DD'),
    end: dayjs('2023-02-28').add(60, 'day').format('YYYY-MM-DD'),
    extendedProps: {
      reportingDate: '2023-02-28',
      deadline: dayjs('2023-02-28').add(60, 'day').format('YYYY-MM-DD'),
      description: 'Liquidity Monitoring Tools',
      perimeter:
        'Financial group or single entity<br/>Highest aggregation level (consolidated level of financial group, otherwise single entity)',
      requiredBy: 'FINMA',
      requirementLink: 'https://emi.snb.ch/en/emi/LMT',
      internalRoute: '/statistics/LMT_GO'
    },
    display: 'background',
    color: 'warning',
    classNames: `border border-2 border-warning bg-warning`
  },
  {
    id: uuid(),
    title: `NSFR_PQ/GQ`,
    start: dayjs('2023-02-28').add(60, 'day').format('YYYY-MM-DD'),
    end: dayjs('2023-02-28').add(60, 'day').format('YYYY-MM-DD'),
    extendedProps: {
      reportingDate: '2023-02-28',
      deadline: dayjs('2023-02-28').add(60, 'day').format('YYYY-MM-DD'),
      description: 'Net stable funding ratio (NSFR)',
      perimeter: 'Financial group or single entity',
      requiredBy: 'FINMA',
      requirementLink: 'https://emi.snb.ch/en/emi/NSFR',
      internalRoute: '/statistics/NSFR_P'
    },
    display: 'background',
    color: 'danger',
    classNames: `border border-2 border-danger bg-danger`
  },
  {
    id: uuid(),
    title: `P_Basel3`,
    start: dayjs('2023-02-28').add(42, 'day').format('YYYY-MM-DD'),
    end: dayjs('2023-02-28').add(42, 'day').format('YYYY-MM-DD'),
    extendedProps: {
      reportingDate: '2023-02-28',
      deadline: dayjs('2023-02-28').add(42, 'day').format('YYYY-MM-DD'),
      description:
        'eligible and required capital, credit risks, market risks, operational risks, unsettled transactions',
      perimeter: 'P_Basel3 -> Parent company',
      requiredBy: 'FINMA',
      requirementLink: 'https://emi.snb.ch/en/emi/BASEL3',
      internalRoute: '/statistics/CRSABIS'
    },
    display: 'background',
    color: 'warning',
    classNames: `border border-2 border-warning bg-warning`
  },
  {
    id: uuid(),
    title: `LCR_G, LCR_P`,
    start: dayjs('2023-02-28').add(20, 'day').format('YYYY-MM-DD'),
    end: dayjs('2023-02-28').add(20, 'day').format('YYYY-MM-DD'),
    extendedProps: {
      reportingDate: '2023-04-30',
      deadline: dayjs('2023-04-30').add(20, 'day').format('YYYY-MM-DD'),
      description: 'Short-term liquidity coverage ratio (LCR)',
      perimeter: 'Financial group and/or single entity',
      requiredBy: 'FINMA',
      requirementLink: 'https://emi.snb.ch/en/emi/LCR',
      internalRoute: '/statistics/LCR_G'
    },
    display: 'background',
    color: 'primary',
    classNames: `border border-2 border-primary bg-primary`
  },
  {
    id: uuid(),
    title: `LCR_G, LCR_P`,
    start: dayjs('2023-04-30').add(20, 'day').format('YYYY-MM-DD'),
    end: dayjs('2023-04-30').add(20, 'day').format('YYYY-MM-DD'),
    extendedProps: {
      reportingDate: '2023-04-30',
      deadline: dayjs('2023-04-30').add(20, 'day').format('YYYY-MM-DD'),
      description: 'Short-term liquidity coverage ratio (LCR)',
      perimeter: 'Financial group and/or single entity',
      requiredBy: 'FINMA',
      requirementLink: 'https://emi.snb.ch/en/emi/LCR',
      internalRoute: '/statistics/MONA'
    },
    display: 'background',
    color: 'primary',
    classNames: `border border-2 border-primary bg-primary`
  }
];

export default reportsCalendar;
