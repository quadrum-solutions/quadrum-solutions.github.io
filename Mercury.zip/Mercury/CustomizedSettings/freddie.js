window.ENV = {
  API_URL: 'https://localhost/api',
  KEYCLOAK_URL: 'https://localhost/keycloak',
  KEYCLOAK_REALM: 'Mercury',
  KEYCLOAK_CLIENT_ID: 'mercury-app',
  KEYCLOAK_SECRET: ''
};
